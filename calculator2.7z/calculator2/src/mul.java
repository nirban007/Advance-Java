public class mul {
   public int mul(int a, int b){

       return a*b;
   }

   
}