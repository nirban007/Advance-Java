import java.util.Scanner;
public class Cal {
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Chose your operation");
        System.out.println("1 for Addition");
        System.out.println("2 for Subtraction");
        System.out.println("3 for Multiplication");
        System.out.println("4 for Divition");
        int chose = scan.nextInt();
        System.out.println("Enter Two Numbers");
        int x=scan.nextInt();
        int y=scan.nextInt();
        if(chose == 1){
            add obj = new add();
	    System.out.println("The ans is: "+obj.add(x, y));
        }
        else if(chose==2){
            sub obj = new sub();
	    System.out.println("The ans is: "+obj.sub(x, y));
        }
        else if(chose==3){
            mul obj = new mul();
	    System.out.println("The ans is: "+obj.mul(x, y));
        }
        else if(chose==4){
            div obj = new div();
	    System.out.println("The ans is: "+obj.div(x, y));
        }
        else{
            System.out.println("Invalid Option");
        }
        
    }

}